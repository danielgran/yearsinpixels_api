from yearsinpixels_data.Repository.Repository import Repository


class UserRepository(Repository):
    def create(self, entity):
        user = User()

    def read(self, entity):
        pass

    def update(self, entity):
        pass

    def delete(self, entity):
        pass

    def initialize(self, data_strategy):
        pass
