from abc import ABC

from yearsinpixels_data.EntityMap.Datatype import Datatype


class DatatypeDate(Datatype, ABC):
    pass
