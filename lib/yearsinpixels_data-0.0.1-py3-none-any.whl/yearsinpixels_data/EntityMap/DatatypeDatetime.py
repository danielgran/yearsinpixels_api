from abc import ABC

from yearsinpixels_data.EntityMap.Datatype import Datatype


class DatatypeDatetime(Datatype, ABC):
    pass
