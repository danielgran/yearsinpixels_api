from abc import ABC

from yearsinpixels_data.EntityMap.Datatype import Datatype


class DatatypeString(Datatype, ABC):
    pass