class Datapair:
    def __init__(self, datatype, field_name):
        self.datatype = datatype
        self.field_name = field_name
