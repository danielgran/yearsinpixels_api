from abc import ABC

from yearsinpixels_data.EntityMap.Datatype import Datatype


class DatatypeInteger(Datatype, ABC):
    pass