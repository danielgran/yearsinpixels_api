from yearsinpixels_business.Entity.User import User


class QueryObject:


    def addCriteria(self, criteria):
        a = User()