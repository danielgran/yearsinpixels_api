class User:

    name = ""